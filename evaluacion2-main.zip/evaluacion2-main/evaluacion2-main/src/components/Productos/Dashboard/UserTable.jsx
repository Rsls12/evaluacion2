import React from 'react';
import UserRow from './UserRow';
const UserTable = ({ users }) => {
  return (
    <div className="box">
      <h2>Usuarios registrados</h2>
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => <UserRow key={user.id} user={user} />)}
        </tbody>
      </table>
    </div>
  );
};

export default UserTable;