import React from 'react';
import './Dashboard.css';

const MetricCard = ({ title, value }) => {
  return (
    <div className="card">
      <h3>{title}</h3>
      <p>{value}</p>
    </div>
  );
};

export default MetricCard;

