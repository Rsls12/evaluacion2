import React from 'react';
import UserRow from './UserRow';
const OrderTable = ({ ordenes }) => {
  return (
    <div className="box">
      <h2>Listado de ordenes</h2>
      <table>
        <thead className='bbb'>
          <tr><th>#ID</th><th>Usuario</th><th>Fecha de órden</th><th>Total</th><th>Estado</th></tr>
        </thead>
        <tbody>
          {ordenes.map((orden, index) => (
            <tr key={index}>
              <td className="red">#{orden.id}</td>
              <td>{orden.usuario}</td>
              <td>{orden.fecha}</td>
              <td>S/{orden.total}</td>
              <td className="green">{orden.estado}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OrderTable;