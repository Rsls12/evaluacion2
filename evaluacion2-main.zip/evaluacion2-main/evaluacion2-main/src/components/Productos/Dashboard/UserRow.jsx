import React from 'react';

const UserRow = ({ user }) => {
  let button;
  if (user.estado === 'Activo') {
    button = <button className="btn-red">Desactivar</button>;
  } else {
    button = <button className="btn-green">Activar</button>;
  }

  return (
    <tr>
      <td><img src={user.img} alt="" className="avatar" /> {user.nombre}</td>
      <td className={user.estado === 'Activo' ? 'green' : 'red'}>{user.estado}</td>
      <td>{button}<button className="btn-outline">Ver detalle</button></td>
    </tr>
  );
};

export default UserRow;