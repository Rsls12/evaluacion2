import React, { useState } from 'react';
import UserTable from '../Dashboard/UserTable.jsx';
import UserDetail from '../Dashboard/UserDetail.jsx';
import OrderTable from '../Dashboard/OrderTable.jsx';
import MetricCard from '../Dashboard/MetricCard.jsx';
import './Dashboard.css';

import './Dashboard.css';

const Dashboard = () => {
  const usuarios = [
    { id: 1, nombre: 'Juan Perez', estado: 'Activo', img: 'https://i.pravatar.cc/40?img=1' },
    { id: 2, nombre: 'María Gonzales', estado: 'Activo', img: 'https://i.pravatar.cc/40?img=2' },
    { id: 3, nombre: 'Marco Aurelio', estado: 'Activo', img: 'https://i.pravatar.cc/40?img=2' },
    { id: 4, nombre: 'Ana Días', estado: 'Activo', img: 'https://i.pravatar.cc/40?img=2' },
    { id: 5, nombre: 'Carlos Lopez', estado: 'Activo', img: 'https://i.pravatar.cc/40?img=2' },
    { id: 6, nombre: 'Laura Mendez', estado: 'Activo', img: 'https://i.pravatar.cc/40?img=2' },
    { id: 7, nombre: 'Alejandro Ruiz', estado: 'Inactivo', img: 'https://i.pravatar.cc/40?img=3' },

  ];

  const usuarioSeleccionado = {
    nombre: 'Juan Perez',
    email: 'juan.perez@gmail.com',
    fechaRegistro: '20/01/2025',
    estado: 'Activo',
    img: 'https://i.pravatar.cc/100?img=1',
    ordenes: [
      { id: '1234', fecha: '20/01/2025', total: '199.00' },
      { id: '2356', fecha: '20/02/2025', total: '199.00' },
      { id: '4577', fecha: '20/03/2025', total: '199.00' },
      { id: '3743', fecha: '20/03/2025', total: '199.00' },
      { id: '3743', fecha: '20/03/2025', total: '199.00' },
      { id: '3743', fecha: '20/03/2025', total: '199.00' },

    ]
  };

  const ordenes = [
    { id: '1234', usuario: 'Alejandro Ruiz', fecha: '20/01/2025', total: '199.00', estado: 'Entregado' },
    { id: '1234', usuario: 'Alejandro Ruiz', fecha: '20/01/2025', total: '199.00', estado: 'Entregado' },
    { id: '1234', usuario: 'Alejandro Ruiz', fecha: '20/01/2025', total: '199.00', estado: 'Entregado' },
    { id: '1234', usuario: 'Alejandro Ruiz', fecha: '20/01/2025', total: '199.00', estado: 'Entregado' },
  ];

  return (
    <div className="dashboard">
      <h1>Dashboard</h1>
      <div className="metrics">
        <MetricCard title="Órdenes" value="68" />
        <MetricCard title="Usuarios nuevos" value="12" />
        <MetricCard title="Ingresos totales" value="S/2348.00" />
      </div>
      <div className="content">
        <UserTable users={usuarios} />
        <UserDetail user={usuarioSeleccionado} />
      </div>
      <OrderTable ordenes={ordenes} />
    </div>
  );
};

export default Dashboard;