import React from 'react';
import boton from '../../../../public/img/cruz.png';
import '../Agregar/Agregar.css';

const Agregar = ({
  nombre,
  setNombre,
  presentacion,
  setPresentacion,
  categoria,
  setCategoria,
  descripcion,
  setDescripcion,
}) => {
  return (
    <div className="contenedor-agregar">
      <h1>Agregar un producto</h1>

      <main className="formulario-producto">
        <h2>Nombre del producto</h2>
        <input
          type="text"
          placeholder="Nombre del producto"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
        />

        <h2>Presentación</h2>
        <input
          type="text"
          placeholder="Presentación"
          value={presentacion}
          onChange={(e) => setPresentacion(e.target.value)}
        />

        <h2>Categoría</h2>
        <div className="fila-categoria">
          <select
            name="categoria"
            value={categoria}
            onChange={(e) => setCategoria(e.target.value)}
          >
            <option value="">Seleccione la categoría del producto</option>
            <option value="Frutas y verduras">Frutas y verduras</option>
            <option value="Lácteos y huevos">Lácteos y huevos</option>
            <option value="Carnes, aves y pescados">Carnes, aves y pescados</option>
          </select>
          <button className="btn-agregar">
            <img src={boton} alt="cruz" />
          </button>
        </div>

        <h2>Descripción</h2>
        <textarea
          placeholder="Descripción del producto"
          rows="4"
          cols="50"
          value={descripcion}
          onChange={(e) => setDescripcion(e.target.value)}
        ></textarea>
      </main>
    </div>
  );
};

export default Agregar;

