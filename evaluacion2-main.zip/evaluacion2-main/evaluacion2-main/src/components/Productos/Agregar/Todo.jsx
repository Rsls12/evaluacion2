import React, { useState } from "react";
import Agregar from "./Agregar.jsx";
import Foto from "./Foto.jsx";
import Foot from "./Foot.jsx";
import "../Agregar/Todo.css";

const Todo = () => {
  // Estado para controlar inputs de Agregar
  const [nombre, setNombre] = useState("");
  const [presentacion, setPresentacion] = useState("");
  const [categoria, setCategoria] = useState("");
  const [descripcion, setDescripcion] = useState("");

  // Estado para controlar input de Foto
  const [imagen, setImagen] = useState("/img/ingreso.png");

  // Estado para controlar input de Foot (stock)
  const [stock, setStock] = useState("");

  // Funciones para limpiar todo
  const limpiarTodo = () => {
    setNombre("");
    setPresentacion("");
    setCategoria("");
    setDescripcion("");
    setImagen("/img/ingreso.png");
    setStock("");
  };

  // Función para validar y limpiar al agregar
  const handleAgregarProducto = () => {
    if (
      nombre.trim() === "" &&
      presentacion.trim() === "" &&
      categoria.trim() === "" &&
      descripcion.trim() === "" &&
      imagen === "/img/ingreso.png" &&  // imagen no cambiada
      stock.trim() === ""
    ) {
      alert("Producto agregado");
      impiarTodo();
    }
    else{
        alert("Producto agregado");
    }

  };

  return (
    <div className="contenedor-flex">
  <Agregar
    nombre={nombre}
    setNombre={setNombre}
    presentacion={presentacion}
    setPresentacion={setPresentacion}
    categoria={categoria}
    setCategoria={setCategoria}
    descripcion={descripcion}
    setDescripcion={setDescripcion}
  />
  
  <div className="contenedor-vertical">
    <Foto imagen={imagen} setImagen={setImagen} />
    <Foot stock={stock} setStock={setStock} onAgregar={handleAgregarProducto} />
  </div>
</div>

  );
};

export default Todo;
