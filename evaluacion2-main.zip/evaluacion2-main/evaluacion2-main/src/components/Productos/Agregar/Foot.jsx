import React from "react";
import cruce from "../../../../public/img/cruz.png";
import "./Foot.css";

const Foot = ({ stock, setStock, onAgregar }) => {
  return (
    <div>
      <main>
        <h1>Stock</h1>
        <input
          type="number"
          min="0"
          max="1000"
          value={stock}
          onChange={(e) => setStock(e.target.value)}
        />
      </main>
      <button className="re" onClick={onAgregar}>
        <img src={cruce} alt="cuz" />
        Crear producto
      </button>
    </div>
  );
};

export default Foot;
