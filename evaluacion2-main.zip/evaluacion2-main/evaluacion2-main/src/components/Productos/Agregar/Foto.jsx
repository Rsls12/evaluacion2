import React, { useState } from 'react';

const Foto = () => {
  const [imagen, setImagen] = useState('/img/ingreso.png');

  const manejarCambioImagen = (evento) => {
    const archivo = evento.target.files[0];
    if (archivo) {
      const urlTemporal = URL.createObjectURL(archivo);
      setImagen(urlTemporal);
    }
  };

  return (
    <>
      <div className="foton">
        <img src={imagen} alt="Foto subida" className="foto-container" />
        <br />
        <h1>Arrastra la imagen</h1>
        <h1>o</h1>
        <input
          type="file"
          accept="image/*"
          onChange={manejarCambioImagen}
        />
      </div>
    </>
  );
};

export default Foto;
