import React from 'react'

const Listap = ({ img, id, nombre, presentacion, descripcion, categoria, stock, Acciones }) => {
  return (
    <tr>
      <td><img src={img} alt={nombre} width="50" /></td>
      <td>{id}</td>
      <td>{nombre}</td>
      <td>{presentacion}</td>
      <td>{descripcion}</td>
      <td>{categoria}</td>
      <td>{stock}</td>
      <td><img src={Acciones} alt="acción" width="60px" /></td>
    </tr>
  )
}

export default Listap
