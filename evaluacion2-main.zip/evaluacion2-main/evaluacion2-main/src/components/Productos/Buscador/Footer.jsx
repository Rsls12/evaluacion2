import React from 'react'
import mayor from '../../../../public/img/mayor.png'
import menor from '../../../../public/img/menor.png'
import '../Buscador/Footer.css'
const Footer = () => {
  return (
    <div className='tr'>
      <ul>
        <li><img src={menor} alt="" /></li>
        <li>1</li>
        <li>2</li>
        <li>3</li>
        <li>...</li>
        <li>10</li>
        <li><img src={mayor} alt="" /></li>
      </ul>
    </div>
  )
}

export default Footer
