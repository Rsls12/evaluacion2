import React, { useState, useEffect } from 'react'
import imagene from '../../../../public/img/cruz.png'
import '../Buscador/Total.css'
import ih from '../../../../public/img/accion.png'
import Listap from '../Buscador/Listap.jsx'
import Footer from './Footer.jsx'
const Total = () => {
    const valores=[
        {
            img:'https://fundaciondelcorazon.com/images/stories/corazon-facil/impulso-vital/uvas.jpg',
            id:"#8123",
            nombre:"Uvas",
            presentacion:0.8,
            descripcion:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ....',
            categoria:'Frutas y verduras',
            stock:10,
            Acciones:{ih}

        },
         {
            img:'https://content.cuerpomente.com/medio/2024/05/28/pera_8ea4bd9a_240528181735_1200x630.jpg',
            id:"#4343",
            nombre:"Peras",
            presentacion:0.1,
            descripcion:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ....',
            categoria:'Frutas y verduras',
            stock:21,
            Acciones:{ih}

        },
         {
            img:'https://www.bupasalud.com/sites/default/files/inline-images/fuji-red.jpg',
            id:"#0223",
            nombre:"Manzanas Rojas",
            presentacion:0.3,
            descripcion:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ....',
            categoria:'Frutas y verduras',
            stock:21,
            Acciones:{ih}

        },
         {
            img:'	https://libera.pe/wp-content/uploads/2022/02/sandia-1080x675.jpg',
            id:"#4344",
            nombre:"Sandía",
            presentacion:1,
            descripcion:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ....',
            categoria:'Frutas y verduras',
            stock:10,
            Acciones:{ih}

        },
         {
            img:'https://www.miamarket.pe/assets/uploads/b23929e1fd650abfe060a8015ae3c164.png',
            id:"#6425",
            nombre:"Leche gloria",
            presentacion:6,
            descripcion:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ....',
            categoria:'Lacteos y huevos',
            stock:30,
            Acciones:{ih}

        },
         {
            img:'https://www.avicolaramavi.com/wp-content/webp-express/webp-images/uploads/2024/05/pollo-1.png.webp',
            id:"#5454",
            nombre:"Pollo entero fresco con menudencia",
            presentacion:2.2,
            descripcion:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ....',
            categoria:'Carnes, aves y pescados',
            stock:3,
            Acciones:{ih}

        },
         {
            img:'https://lirp.cdn-website.com/586fb047/dms3rep/multi/opt/papaya-1920w.jpg',
            id:"#2344",
            nombre:"Papaya",
            presentacion:0.8,
            descripcion:'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ....',
            categoria:'Frutas y verduras',
            stock:15,
            Acciones:{ih}

        }
    ]
  const [filteredValue, setFilteredValue] = useState('');
  const [filteredTotal, setFilteredTotal] = useState(valores);

  const filterTotal = () => {
    const resultado = valores.filter(producto =>
      producto.nombre.toLowerCase().includes(filteredValue.toLowerCase())
    );
    setFilteredTotal(resultado);
  };

  useEffect(() => {
    if (filteredValue === '') {
      setFilteredTotal(valores);
    }
  }, [filteredValue]);
  return (<>
    <aside className='pep'>
        <h1>Listado de productos</h1>
    </aside>
    <div className='bot'>
            <input type="text" 
            value={filteredValue}
            onChange={(e) => setFilteredValue(e.target.value)}
             placeholder='Buscar producto......' />
            <button className='rew'
            onClick={()=>filterTotal()}
            >Buscar</button>
            <button className='reeew'>
              <ul>
                <li><div></div></li>
                <li><div></div></li>
                <li><div></div></li>
              </ul>
              Categorías
            </button>
            <button>
              <img src={imagene} alt="cruz" />
              Agregar producto
            </button>
          </div>
          <section>
  <main className="tabla-container">
    <table>
      <thead>
        <tr>
          <th>Imagen</th>
          <th>Id</th>
          <th>Nombre</th>
          <th>Presentación</th>
          <th>Descripción</th>
          <th>Categoría</th>
          <th>Stock</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        {
          filteredTotal.map(producto => (
            <Listap
              key={producto.id}
              img={producto.img}
              id={producto.id}
              nombre={producto.nombre}
              presentacion={producto.presentacion}
              descripcion={producto.descripcion}
              categoria={producto.categoria}
              stock={producto.stock}
              Acciones={ih}
            />
          ))
        }
      </tbody>
    </table>
  </main>
</section>
<Footer/>
          </>
          )
}

export default Total;
