// src/data/juegosAPI.js

const productos = [
  {
    id: 1,
    nombre: "Pollo entero fresco",
    descripcion: "Presentación 2.2 kg aprox",
    precio: 20.65,
    imagen: "https://th.bing.com/th/id/R.411c2553c5eda4d83ab0b5c5fe81a9e0?rik=BL4r4m4rA%2bRCYQ&pid=ImgRaw&r=0"
  },
  {
    id: 2,
    nombre: "Leche Gloria",
    descripcion: "Pack 6 unidades",
    precio: 22.65,
    imagen: "https://th.bing.com/th/id/OIP.fDFszZCUN5EUkRed5ytSbAHaHa?w=159&h=180&c=7&r=0&o=5&pid=1.7"
  }
];

export default productos; // ✅ esta línea es crucial
