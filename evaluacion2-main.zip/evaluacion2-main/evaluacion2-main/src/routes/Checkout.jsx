import CheckoutPage from '../components/Checkout/Checkout.jsx'

const Checkout = () => {
    return (
        <CheckoutPage />
    )
}

export default Checkout;