import CatalogoPage from '../components/Catalogo/Catalogo'

const Catalogo = () => <CatalogoPage />;
export default Catalogo;
