import CartPage from '../components/Cart/Cart.jsx'

const Cart = () => {
    return (
        <CartPage />
    )
}

export default Cart;