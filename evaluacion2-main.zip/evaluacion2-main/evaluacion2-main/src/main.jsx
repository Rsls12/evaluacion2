import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import CartProvider from "./context/CartContext.jsx" // 

import './index.css';
import App from './home/app.jsx'; 
import Cart from './routes/Cart.jsx';
import Checkout from './routes/Checkout.jsx';
import Fin from './routes/Fin.jsx';
import Catalogo from './routes/Catalogo.jsx';
import Resultados from './resultados.jsx';
import Todo from './components/Productos/Agregar/Todo.jsx';
import Total from './components/Productos/Buscador/Total.jsx';
import Dashboard from './components/Productos/Dashboard/Dashboard.jsx';

    
const router = createBrowserRouter([
  { path: '/', element: <App /> },
  { path: '/cart', element: <Cart /> },
  { path: '/form', element: <Checkout /> },
  { path: '/end', element: <Fin /> },
  { path: '/catalogo', element: <Catalogo /> },
  { path: '/resultados', element: <Resultados /> },
  {path: '/todo', element: <Todo/>},
  {path:'/lista', element:<Total/>},
  {path:'/admin', element:<Dashboard/>}
  
])

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <CartProvider>
      <RouterProvider router={router} />
    </CartProvider>
  </StrictMode>
);